Redirection to German PayPal Site
=================================
Log in in PayPal and set Language in the settings to English
http://www.smartstore.com/forum/showthread.php?t=10160

Project Name
============
Donation can go to donate names and allow the users to specify the amount direclty on PayPal.
http://www.gutenberg.org/wiki/Gutenberg:The_CD_and_DVD_Project

hidden field was added to specify country code.
